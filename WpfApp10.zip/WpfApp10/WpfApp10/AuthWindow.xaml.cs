﻿using System.Windows;

namespace BroMessenger
{
    public partial class AuthWindow : Window
    {
        public AuthWindow()
        {
            InitializeComponent();
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            // Здесь можно добавить проверку логина/пароля
            var mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }
    }
}